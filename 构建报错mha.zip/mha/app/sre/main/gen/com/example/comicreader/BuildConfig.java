/** Automatically generated file. DO NOT MODIFY */
package com.example.comicreader;

public final class BuildConfig {
    public final static boolean DEBUG = true;
    public final static String APPLICATION_ID = "com.example.comicreader";
    public final static String BUILD_TYPE = "debug";
    public final static long VERSION_CODE = 0;
    public final static String VERSION_NAME = "null";
}