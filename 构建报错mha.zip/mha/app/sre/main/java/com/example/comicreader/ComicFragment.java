package com.example.comicreader;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ComicFragment extends Fragment {

    private RecyclerView recyclerView;
    private ComicAdapter comicAdapter;
    private List<ComicItem> comicList;
    private static final int REQUEST_CODE_PICK_FILE = 1001;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, 
							 @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_comic, container, false);

        initViews(view);
        setupRecyclerView();

        return view;
    }

    private void initViews(View view) {
        recyclerView = view.findViewById(R.id.recycler_view);

        // 设置加号按钮点击事件
        view.findViewById(R.id.fab_add).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					openFilePicker();
				}
			});

        comicList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        comicAdapter = new ComicAdapter(comicList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(comicAdapter);
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/zip");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "选择压缩包"), REQUEST_CODE_PICK_FILE);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getContext(), "请安装文件管理器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == getActivity().RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                new ZipProcessingTask().execute(uri);
            }
        }
    }

    private class ZipProcessingTask extends AsyncTask<Uri, Void, ComicItem> {

        @Override
        protected ComicItem doInBackground(Uri... uris) {
            try {
                InputStream inputStream = getActivity().getContentResolver().openInputStream(uris[0]);
                ZipInputStream zipInputStream = new ZipInputStream(inputStream);

                ZipEntry entry;
                String comicName = null;
                Bitmap firstImage = null;

                while ((entry = zipInputStream.getNextEntry()) != null) {
                    String entryName = entry.getName();

                    // 获取压缩包名称（不包含后缀）
                    if (comicName == null) {
                        String fileName = getFileNameFromUri(uris[0]);
                        comicName = fileName.substring(0, fileName.lastIndexOf('.'));
                    }

                    // 查找第一个webp图片
                    if (entryName.toLowerCase().endsWith(".webp") && firstImage == null) {
                        try {
                            // 读取图片数据
                            byte[] buffer = new byte[1024];
                            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
                            int len;
                            while ((len = zipInputStream.read(buffer)) > 0) {
                                outputStream.write(buffer, 0, len);
                            }

                            byte[] imageData = outputStream.toByteArray();
                            firstImage = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
                            outputStream.close();

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    zipInputStream.closeEntry();

                    // 如果已经找到第一张图片，可以提前退出
                    if (firstImage != null && comicName != null) {
                        break;
                    }
                }

                zipInputStream.close();

                if (comicName != null && firstImage != null) {
                    return new ComicItem(comicName, firstImage);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(ComicItem comicItem) {
            if (comicItem != null) {
                comicList.add(comicItem);
                comicAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getContext(), "导入失败", Toast.LENGTH_SHORT).show();
            }
        }

        private String getFileNameFromUri(Uri uri) {
            String result = null;
            if (uri.getScheme().equals("content")) {
                android.database.Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
                try {
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if (nameIndex != -1) {
                            result = cursor.getString(nameIndex);
                        }
                    }
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
            if (result == null) {
                result = uri.getPath();
                int cut = result.lastIndexOf('/');
                if (cut != -1) {
                    result = result.substring(cut + 1);
                }
            }
            return result;
        }
    }
}
