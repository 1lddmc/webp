package com.example.comicreader;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class SettingsFragment extends Fragment {

    private ListView listView;
    private List<String> settingsList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, 
							 @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        initViews(view);
        setupListView();

        return view;
    }

    private void initViews(View view) {
        listView = view.findViewById(R.id.list_view);

        settingsList = new ArrayList<>();
        settingsList.add("参数");
        settingsList.add("关于");
    }

    private void setupListView() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
            getContext(), 
            android.R.layout.simple_list_item_1, 
            settingsList
        );

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					switch (position) {
						case 0: // 参数
							showParameters();
							break;
						case 1: // 关于
							showAbout();
							break;
					}
				}
			});
    }

    private void showParameters() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getContext());
        builder.setTitle("参数设置")
			.setMessage("这里是参数设置页面")
			.setPositiveButton("确定", null)
			.show();
    }

    private void showAbout() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(getContext());
        builder.setTitle("关于")
			.setMessage("漫画阅读器 v1.0\n\n开发人员: Your Name")
			.setPositiveButton("确定", null)
			.show();
    }
}
