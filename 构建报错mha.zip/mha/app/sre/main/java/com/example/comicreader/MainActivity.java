package com.example.comicreader;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private FrameLayout fragmentContainer;
    private Button btnComic, btnSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupNavigation();

        // 默认显示漫画界面
        showComicFragment();
    }

    private void initViews() {
        fragmentContainer = findViewById(R.id.fragment_container);
        btnComic = findViewById(R.id.nav_comic);
        btnSettings = findViewById(R.id.nav_settings);
    }

    private void setupNavigation() {
        btnComic.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showComicFragment();
				}
			});

        btnSettings.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showSettingsFragment();
				}
			});
    }

    private void showComicFragment() {
        fragmentContainer.removeAllViews();
        View comicView = getLayoutInflater().inflate(R.layout.fragment_comic, null);
        fragmentContainer.addView(comicView);
    }

    private void showSettingsFragment() {
        fragmentContainer.removeAllViews();
        View settingsView = getLayoutInflater().inflate(R.layout.fragment_settings, null);
        fragmentContainer.addView(settingsView);
    }
}
