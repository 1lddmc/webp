package com.example.comicreader;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ComicAdapter extends RecyclerView.Adapter<ComicAdapter.ComicViewHolder> {

    private List<ComicItem> comicList;

    public ComicAdapter(List<ComicItem> comicList) {
        this.comicList = comicList;
    }

    @Override
    public ComicViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
			.inflate(R.layout.item_comic, parent, false);
        return new ComicViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ComicViewHolder holder, int position) {
        ComicItem comicItem = comicList.get(position);
        holder.textComicName.setText(comicItem.getName());
        holder.imagePreview.setImageBitmap(comicItem.getFirstImage());
    }

    @Override
    public int getItemCount() {
        return comicList.size();
    }

    public static class ComicViewHolder extends RecyclerView.ViewHolder {
        public TextView textComicName;
        public ImageView imagePreview;

        public ComicViewHolder(View itemView) {
            super(itemView);
            textComicName = itemView.findViewById(R.id.text_comic_name);
            imagePreview = itemView.findViewById(R.id.image_preview);
        }
    }
}
