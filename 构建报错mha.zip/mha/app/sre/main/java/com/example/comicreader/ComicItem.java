package com.example.comicreader;

import android.graphics.Bitmap;

public class ComicItem {
    private String name;
    private Bitmap firstImage;

    public ComicItem(String name, Bitmap firstImage) {
        this.name = name;
        this.firstImage = firstImage;
    }

    public String getName() {
        return name;
    }

    public Bitmap getFirstImage() {
        return firstImage;
    }
}
